@extends('adminlte::page')

@section('title', 'Admin page')

@section('content_header')
    <h1>Admin page</h1>
@stop

@section('content')
    <p>Welcome to this beautiful admin panel.</p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop
