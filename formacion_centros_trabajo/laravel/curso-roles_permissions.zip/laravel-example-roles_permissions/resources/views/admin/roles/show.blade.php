@extends('adminlte::page')

@section('title', 'Admin page')

@section('content_header')
    <h1>Mostrar rol</h1>
@stop

@section('content')
    <p>Welcome to this beautiful admin panel.</p>
@stop