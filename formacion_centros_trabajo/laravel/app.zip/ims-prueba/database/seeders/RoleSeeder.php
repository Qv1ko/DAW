<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call(PermissionSeeder::class);

        Role::create(['name' => 'admin'])->syncPermissions(Permission::all());
        Role::create(['name' => 'editor'])->syncPermissions(['create', 'update', 'delete', 'export', 'import', 'read']);
        Role::create(['name' => 'user'])->syncPermissions(['read']);
    }
}
