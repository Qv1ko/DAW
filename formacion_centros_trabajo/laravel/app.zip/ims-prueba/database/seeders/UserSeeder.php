<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->call(RoleSeeder::class);

        User::create([
            'name' => 'admin',
            'email' => 'admin@ims.es',
            'phone' => '1234567890',
            'departament' => 'IT',
            'password' => bcrypt('admin'),
        ])->assignRole('admin');

        User::create([
            'name' => 'OldAutos Burgos',
            'email' => 'oldautos@oldautos.es',
            'phone' => '0987654321',
            'departament' => 'Dealer',
            'password' => bcrypt('oldautos'),
        ])->assignRole('editor');

        User::create([
            'name' => 'user',
            'email' => 'user@ims.es',
            'phone' => '1122334455',
            'departament' => 'Marketing',
            'password' => bcrypt('user'),
        ])->assignRole('user');
    }
}
