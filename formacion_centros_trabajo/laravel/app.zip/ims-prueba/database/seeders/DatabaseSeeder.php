<?php

namespace Database\Seeders;

use App\Models\Brand;
use App\Models\Vehicle;
use App\Models\Dealership;
use App\Models\ZoneManager;
use Illuminate\Database\Seeder;
use Database\Seeders\UserSeeder;
use Database\Seeders\ProvinceSeeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([UserSeeder::class]);

        $this->call([ProvinceSeeder::class]);
        ZoneManager::factory(10)->create();
        Dealership::factory(20)->create();
        Brand::factory(20)->create();
        Vehicle::factory(400)->create();
    }
}
