<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Brand;
use App\Models\Dealership;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class VehicleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $word = fake()->word();
        $lastName = fake()->lastName();

        $rand1Dig = fake()->randomDigit();
        $rand3Digs = fake()->randomNumber(3, true);
        $rand4Digs = fake()->randomNumber(4, true);

        $rand1Let = fake()->randomLetter();
        $rand2Lets = fake()->lexify('??');
        $rand3Lets = fake()->lexify('???');

        $rand3Digs1Let = fake()->bothify('###?');

        $rand1Let1Dig = fake()->bothify('?#');
        $rand1Let3Digs = fake()->bothify('?###');
        $rand1Let2Digs = fake()->bothify('?##');
        $rand2Lets1Dig = fake()->bothify('??#');
        $rand2Lets2Digs = fake()->bothify('??##');
        $rand3Lets1Dig = fake()->bothify('???#');
        $rand3Lets3Digs = fake()->bothify('???###');

        $randWord1Dig = $word . " " . $rand1Dig;
        $randWord1Let = $word . " " . $rand1Let;
        $randWordC1Let = $word . "-" . $rand1Let;
        $rand1Let1DigWord = $rand1Let1Dig . " " . $word;
        $rand1Let2DigsWord = $rand1Let2Digs . " " . $word;
        $rand1LetCWord = $rand1Let . "-" . $word;
        $rand3DigsWord = $rand3Digs . " " . $word;
        $rand3LetsWord = $rand3Lets . " " . $word;

        $rand2LetsC1Let = fake()->bothify('??-?');
        $rand2LetsC1Dig = fake()->bothify('??-#');
        $rand2LetsSpa2Digs = fake()->bothify('?? ##');

        $randClase1Dig = fake()->lexify('CLASE ?');
        $randSerie1Dig = fake()->numerify('SERIE #');

        $model = strtoupper(fake()->randomElement([
            $word,
            fake()->randomElement([
                $lastName,
                $randWord1Dig,
                $randWord1Let,
                $randWordC1Let,
                $rand1Let1DigWord,
                $rand1Let2DigsWord,
                $rand1LetCWord,
                $rand3DigsWord,
                $rand3LetsWord,
                $randClase1Dig,
                $randSerie1Dig,
                fake()->randomElement([
                    $rand3Digs1Let,
                    $rand1Let1Dig,
                    $rand1Let3Digs,
                    $rand2Lets1Dig,
                    $rand2Lets2Digs,
                    $rand3Lets1Dig,
                    $rand3Lets3Digs,
                    $rand2LetsC1Dig,
                    $rand2LetsC1Let,
                    $rand2LetsSpa2Digs,
                    fake()->randomElement([
                        $rand1Dig,
                        $rand3Digs,
                        $rand4Digs,
                        $rand1Let,
                        $rand2Lets,
                        $rand3Lets,
                    ])
                ])
            ])
        ]));

        $versionType = fake()->optional(75, "")->randomElement(["DX", "X", "GL", "LTD", "S", "SE", "SL", "GT", "GTI", "GTS", "GTX", "EX", "SR", "SS", "HLX", "XL", "XLS", "SPIDER"]);
        $versionEnergy = fake()->optional(50, "")->randomElement(["E", "HYBRID", "GLP", "D"]);
        $versionComponents = fake()->optional(50, "")->randomElement(["MT", "AT", "AC", "TI", fake()->regexify('V[2-8]'), fake()->numerify('#.#T'), "4x4", "AWD", "2 PTAS", "3 PTAS", "4 PTAS", "5 PTAS"]);

        $version = trim(str_replace("  ", " ", implode(" ", [$versionType, $versionEnergy, $versionComponents])));

        return [
            'vin' => fake()->regexify('^[A-HJ-NPR-Z0-9]{8}[0-9X][A-HJ-NPR-Z0-9]{2}[0-9]{6}$'),
            'brand_id' => Brand::find(rand(1, count(Brand::get()))),
            'model' => $model,
            'version' => $version == "" ? null : $version,
            'external_color' => strtoupper(fake()->hexColor()),
            'dealership_id' => Dealership::find(rand(1, count(Dealership::get()))),
            'price' => fake()->numberBetween(5000, 95000),
        ];
    }
}
