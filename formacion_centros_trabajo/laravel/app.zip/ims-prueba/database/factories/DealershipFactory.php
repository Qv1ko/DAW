<?php

namespace Database\Factories;

use App\Models\Province;
use App\Models\ZoneManager;
use Faker\Provider\es_ES\Payment;
use Faker\Provider\es_ES\PhoneNumber;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class DealershipFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $company = fake()->company();
        $companyReason = $company . ' ' . fake()->randomElement(['S.L.', 'S.A.', 'S.L.U.', 'S.A.L.', 'SLL.', 'S.Coop.']);

        return [
            'commercial_name' => $company,
            'company_reason' => $companyReason,
            'cif' => Payment::vat(),
            'email' => fake()->unique()->freeEmail(),
            'phone' => PhoneNumber::mobileNumber(),
            'code' => fake()->unique()->randomNumber(8, true),
            'province_id' => Province::find(rand(1, count(Province::get()))),
            'zone_manager_id' => ZoneManager::find(rand(1, count(ZoneManager::get()))),
        ];
    }
}
