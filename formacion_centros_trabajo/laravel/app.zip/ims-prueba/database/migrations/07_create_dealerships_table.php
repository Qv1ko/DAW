<?php

use App\Models\Province;
use App\Models\ZoneManager;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dealerships', function (Blueprint $table) {
            $table->id();
            $table->string('commercial_name')->unique();
            $table->string('company_reason')->unique();
            $table->string('cif')->unique();
            $table->string('email')->unique();
            $table->string('phone')->unique();
            $table->string('code')->unique();

            $table->foreignIdFor(Province::class)->nullable()->constrained()->cascadeOnUpdate()->nullOnDelete();
            $table->foreignIdFor(ZoneManager::class)->nullable()->constrained()->cascadeOnUpdate()->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('dealerships');
    }
};
