<h1 align="center">IMS</h1>
<p align="center"><a href="#" target="_blank"><img src="./public/ims.png" width="400" alt="IMS Logo"></a></p>

<p align="center">
<a href="https://laravel.com/docs/12.x"><img src="https://img.shields.io/badge/Laravel%20v12-grey?style=for-the-badge&logo=laravel" alt="Laravel v12"></a>
<a href="https://www.php.net/"><img src="https://img.shields.io/badge/PHP%20v8.2.28-grey?style=for-the-badge&logo=php" alt="PHP v8.2.28"></a>
<a href="https://nodejs.org/"><img src="https://img.shields.io/badge/NodeJS%20v20-grey?style=for-the-badge&logo=node.js" alt="NodeJS v20"></a>
<a href="https://vite.dev/"><img src="https://img.shields.io/badge/Vite%20v6.0.11-grey?style=for-the-badge&logo=vite" alt="Vite v6.0.11"></a>
<a href="https://getcomposer.org/"><img src="https://img.shields.io/badge/Composer%20v2.4.1-grey?style=for-the-badge&logo=composer" alt="Composer v2.4.1"></a>
<a href="https://jquery.com/"><img src="https://img.shields.io/badge/JQuery%20v3.7.1-grey?style=for-the-badge&logo=jquery" alt="JQuery v3.7.1"></a>
</p>

## Sobre IMS
IMS es un proyecto desarrollado durante mis practicas de desarrollo web en [Softeca](https://www.softeca.es).
IMS permite gestionar concesionarios de vehículos, sus responsables, los propios vehículos de los concesionarios y las marcas. Tambien, puedes acceder a diferente información relevante desde el Dashboard y exportar e importar la información con archivos como Excel y .csv.

## Despliega IMS
1. Clona el repositorio.
2. Entra en el repositiorio clonado.
3. Ejecuta el comando `npm update`, y define en un archivo .ENV la configuración de la base de datos.
3. Desde la terminal, ejecuta las migraciones `php artisan migrate` o `php artisan migrate:fresh --seed`.
4. Ejecuta los comandos de despliegue desde dos terminales `npm run dev` y `php artisan serve` en tu terminal.
5. Abre la aplicación en el navegador accediendo a `127.0.0.1:8000`.

## Arbol de directorios
```bash
+---app
|   +---Exports             # Exportar en excel
|   +---Http
|   |   +---Controllers     # Controladores
|   |   \---Requests        # Validaciones
|   +---Imports             # Importar excel
|   +---Mail
|   +---Models              # Modelos
|   +---Providers
|   \---View
|       \---Components
+---bootstrap
+---config                  # Archivos de configuración
+---database
|   +---factories           # Generar de datos falsos
|   +---migrations          # Archivos de migración
|   \---seeders             # Crear datos
+---public
+---resources
|   +---css                 # Estilos
|   +---js                  # Scripts de JavaScript
|   \---views               # Vistas
|       +---auth
|       +---brands          # Vistas de marcas
|       +---components
|       |   \---icons       # Iconos
|       +---dealerships     # Vistas de concesionarios
|       +---emails          # Vista del email
|       +---layouts         # Plantillas
|       +---profile
|       +---vehicles        # Vistas de vehículos
|       +---vendor
|       \---zoneManagers    # Vistas de responsables de zona
+---routes                  # Rutas
+---storage
|   +---app
|   +---debugbar
|   +---framework
|   \---logs
\---tests
    +---Feature
    \---Unit
```

## Tareas implementadas
- [x] Crear un proyecto de Laravel v12 con nombre IMS
- [x] Crea las tablas:
    - Concesionarios (nombre comercial, razón social, CIF, email, teléfono, código, provincia, responsable de zona)
    - Responsables de zona (nombre)
    - Provincias (nombre) -> [API INE](https://servicios.ine.es/wstempus/js/ES/VALORES_VARIABLE/20)
    - Vehículos (VIN, marca, modelo, versión, color exterior)
    - Marcas (nombre)
    - Usuarios
- [x] Relaciona las tablas:
    - Relación: Responsables de zona 1:N Concesionarios
    - Relación: Provincias 1:N Concesionarios
    - Relación: Vehículos N:1 Concesionarios (precio de los vehículos)
    - Relación: Marcas 1:N Vehículos
- [x] Implementa un login
- [x] CRUD de todas las tablas
    - Buscador
    - CRUD
    - Paginación
    - Alertas
- [x] Dasboard
    - Concesionario con mayor y menor precio neto
    - Provincia con más vehículos
    - Valor neto de cada marca
    - Número de vehículos por concesionario
- [x] Buscador en los select
- [x] Ordenar columnas de las tablas al hacer clic
- [x] Optimizar de iconos
- [x] Optimizar de los componentes
- [x] Exportar e importar en excel
- [x] Email de bienvenida
- [x] Alertas en las acciones
- [x] CRUD con API
- [x] Cambiar página de inicio
- [x] Nuevos atributos de los usuarios (nombre, apellido, email, teléfono, departamento, rol, estado)
- [x] Restringir las rutas y vistas
- [ ] CRUD de usuarios
- [ ] Registro de las acciones de los usuarios

## Bibliografía
- **Tutoriales y guías:**
    - **[Laravel](https://laravel.com/docs/12.x)**
    - **[Laravel Best Practices](https://github.com/alexeymezenin/laravel-best-practices)**
    - **[Coders Free](https://www.youtube.com/@CodersFree)**
- **Foros:**
    - **[StackOverflow](https://stackoverflow.com/questions)**
    - **[LaraCast](https://laracasts.com)**
- **Inteligencias artificiales:**
    - **[BlackBox](https://www.blackbox.ai)**
    - **[Perplexity](https://www.perplexity.ai)**
- **Componentes:**
    - **[Column-sortable](https://github.com/Kyslik/column-sortable)**
    - **[Laravel Excel](https://laravel-excel.com)**
    - **[ECharts](https://echarts.apache.org)**
    - **[Select2](https://select2.org/)**
- **Elementos de la UI:**
    - **[FlowBite](https://flowbite.com)**
    - **[Tabler icons](https://tabler.io/icons)**
- **Otras herramientas:**
    - **[CommitLint](https://commitlint.io)**
    - **[Regex101](https://regex101.com)**
    - **[FakerPHP](https://fakerphp.org/)**
    - **[API INE](https://www.ine.es/)**

## Licencia
IMS es un software de código abierto con licencia [MIT](https://opensource.org/licenses/MIT).
