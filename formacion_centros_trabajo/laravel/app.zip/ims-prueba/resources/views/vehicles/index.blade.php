<x-app-layout>
    @if (session('status'))
        <x-alert :text="session('status')" />
    @endif
    <div class="py-6 bg-gray-100 dark:bg-gray-900">
        <div class="max-w-auto mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6 text-gray-800 dark:text-gray-100">
                    <div class="w-full overflow-x-auto">
                        <x-management-table :route="'/vehicles'" :search="$search" :exportRoute="'vehicles.export'" :importRoute="'vehicles.import'"
                            :createRoute="'vehicles.create'" :model="'vehículo'" :attributeList="[
                                'vin' => [
                                    'head' => 'VIN',
                                    'sortBy' => 'vin',
                                    'type' => 'text',
                                    'styles' => 'text-center',
                                ],
                                'brandName' => [
                                    'head' => 'Marca',
                                    'sortBy' => 'brand.name',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'modelVersion' => [
                                    'head' => 'Modelo y versión',
                                    'sortBy' => 'model',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'external_color' => [
                                    'head' => 'Color externo',
                                    'type' => 'color',
                                    'styles' => 'text-center flex items-center justify-center',
                                ],
                                'dealershipCommercialName' => [
                                    'head' => 'Concesionario',
                                    'sortBy' => 'dealership.commercial_name',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'euroPrice' => [
                                    'head' => 'Precio',
                                    'sortBy' => 'price',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                            ]" :items="$vehicles" :editRoute="'vehicles.edit'"
                            :deleteInfo="[
                                'text' => 'Está seguro de que quieres eliminar el vehículo con VIN ',
                                'attribute' => 'vin',
                            ]" :deleteRoute="'vehicles.destroy'" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
