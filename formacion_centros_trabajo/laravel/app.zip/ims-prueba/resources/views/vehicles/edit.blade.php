<x-app-layout>
    <div class="py-6 bg-gray-100 dark:bg-gray-900">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6 text-gray-800 dark:text-gray-100">
                    <div class="w-full overflow-x-auto">
                        <h1 class="text-center text-xl mb-4">Editar vehículo {{ $vehicle->vin }}</h1>
                        <x-form :actionRoute="'vehicles.update'" :parameter="$vehicle->id" :method="'put'" :structure="[
                            [
                                'vin' => [
                                    'label' => 'VIN',
                                    'type' => 'text',
                                    'value' => $vehicle->vin,
                                    'placeholder' => 'SCA664S5XAUX48670',
                                ],
                                'brand_id' => [
                                    'label' => 'Marca',
                                    'type' => 'select',
                                    'value' => $vehicle->brand_id,
                                    'options' => $brands,
                                    'optionAttribute' => 'name',
                                ],
                            ],
                            [
                                'model' => [
                                    'label' => 'Modelo',
                                    'type' => 'text',
                                    'value' => $vehicle->model,
                                    'placeholder' => 'Modelo',
                                ],
                                'version' => [
                                    'label' => 'Versión',
                                    'type' => 'text',
                                    'value' => $vehicle->version,
                                    'placeholder' => 'Versión',
                                ],
                            ],
                            [
                                'dealership_id' => [
                                    'label' => 'Concesionario',
                                    'type' => 'select',
                                    'value' => $vehicle->dealership_id,
                                    'options' => $dealerships,
                                    'optionAttribute' => 'commercial_name',
                                ],
                            ],
                            [
                                'external_color' => [
                                    'label' => 'Color',
                                    'type' => 'color',
                                    'value' => $vehicle->external_color,
                                    'placeholder' => '#000000',
                                ],
                                'price' => [
                                    'label' => 'Precio (€)',
                                    'type' => 'text',
                                    'value' => str_replace('.', ',', $vehicle->price),
                                    'placeholder' => '50000',
                                ],
                            ],
                        ]"
                            :errors="$errors" :submitText="'Actualizar vehículo'" :cancelButtonPath="'/vehicles'" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
