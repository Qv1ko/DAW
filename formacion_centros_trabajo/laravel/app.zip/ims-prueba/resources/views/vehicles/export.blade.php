<table>
    <thead>
        <tr>
            @foreach ($headers as $head)
                <th>{{ $head }}</th>
            @endforeach
        </tr>
    </thead>
    <tbody>
        @foreach ($vehicles as $vehicle)
            <tr>
                <td>{{ $vehicle->id }}</td>
                <td>{{ $vehicle->vin}}</td>
                <td>{{ $vehicle->brand->name }}</td>
                <td>{{ $vehicle->model}}</td>
                <td>{{ $vehicle->version }}</td>
                <td>{{ $vehicle->external_color }}</td>
                <td>{{ $vehicle->dealership->commercial_name }}</td>
                <td>{{ $vehicle->price }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
