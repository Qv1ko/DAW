<x-app-layout>
    <div class="py-6 bg-gray-100 dark:bg-gray-900">
        <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6 text-gray-800 dark:text-gray-100">
                    <div class="w-full overflow-x-auto">
                        <h1 class="text-center text-xl mb-4">Editar responsable {{ $zoneManager->name }}</h1>
                        <x-form :actionRoute="'zoneManagers.update'" :parameter="$zoneManager->id" :method="'put'" :structure="[
                            [
                                'name' => [
                                    'label' => 'Nombre y apellido',
                                    'type' => 'text',
                                    'value' => $zoneManager->name,
                                    'placeholder' => 'Alejando Fernández',
                                ],
                            ],
                        ]"
                            :errors="$errors" :submitText="'Actualizar responsable'" :cancelButtonPath="'/zoneManagers'" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
