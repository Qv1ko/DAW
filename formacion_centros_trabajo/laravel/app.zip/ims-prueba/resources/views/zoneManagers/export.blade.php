<table>
    <thead>
        <tr>
            @foreach ($headers as $head)
                <th>{{ $head }}</th>
            @endforeach
        </tr>
    </thead>
    <tbody>
        @foreach ($zoneManagers as $zoneManager)
            <tr>
                <td>{{ $zoneManager->id }}</td>
                <td>{{ $zoneManager->name}}</td>
            </tr>
        @endforeach
    </tbody>
</table>
