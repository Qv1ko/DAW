<x-app-layout>
    @if (session('status'))
        <x-alert :text="session('status')" />
    @endif
    <div class="py-6 bg-gray-100 dark:bg-gray-900">
        <div class="min-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6 text-gray-800 dark:text-gray-100">
                    <div class="w-full overflow-x-auto">
                        <x-management-table :route="'/dealerships'" :search="$search" :exportRoute="'dealerships.export'" :importRoute="'dealerships.import'"
                            :createRoute="'dealerships.create'" :model="'concesionario'" :attributeList="[
                                'code' => [
                                    'head' => 'Código',
                                    'sortBy' => 'code',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'commercial_name' => [
                                    'head' => 'Nombre comercial',
                                    'sortBy' => 'commercial_name',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'company_reason' => [
                                    'head' => 'Razón social',
                                    'sortBy' => 'company_reason',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'cif' => [
                                    'head' => 'CIF',
                                    'sortBy' => 'cif',
                                    'type' => 'text',
                                    'styles' => 'text-center',
                                ],
                                'email' => [
                                    'head' => 'Email',
                                    'sortBy' => 'email',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'phone' => [
                                    'head' => 'Télefono',
                                    'sortBy' => 'phone',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'provinceName' => [
                                    'head' => 'Provincia',
                                    'sortBy' => 'province.name',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'zoneManagerName' => [
                                    'head' => 'Responsable de zona',
                                    'sortBy' => 'zoneManager.name',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'vehiclesCount' => [
                                    'head' => 'Nº vehículos',
                                    'type' => 'text',
                                    'styles' => 'text-center',
                                ],
                            ]" :items="$dealerships" :editRoute="'dealerships.edit'"
                            :deleteInfo="[
                                'text' => 'Está seguro de que quieres eliminar el concesionario ',
                                'attribute' => 'commercial_name',
                            ]" :deleteRoute="'dealerships.destroy'" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
