<table>
    <thead>
        <tr>
            @foreach ($headers as $head)
                <th>{{ $head }}</th>
            @endforeach
        </tr>
    </thead>
    <tbody>
        @foreach ($dealerships as $dealership)
            <tr>
                <td>{{ $dealership->id }}</td>
                <td>{{ $dealership->commercial_name }}</td>
                <td>{{ $dealership->company_reason }}</td>
                <td>{{ $dealership->cif }}</td>
                <td>{{ $dealership->email }}</td>
                <td>{{ $dealership->phone }}</td>
                <td>{{ $dealership->code }}</td>
                <td>{{ $dealership->province->name }}</td>
                <td>{{ $dealership->zoneManager->name }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
