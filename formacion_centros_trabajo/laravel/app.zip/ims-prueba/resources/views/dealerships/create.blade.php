<x-app-layout>
    <div class="py-6 bg-gray-100 dark:bg-gray-900">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6 text-gray-800 dark:text-gray-100">
                    <div class="w-full overflow-x-auto">
                        <h1 class="text-center text-xl mb-4">Nuevo concesionario</h1>
                        <x-form :actionRoute="'dealerships.store'" :structure="[
                            [
                                'commercial_name' => [
                                    'label' => 'Nombre comercial',
                                    'type' => 'text',
                                    'value' => '',
                                    'placeholder' => 'Nano motor',
                                ],
                                'company_reason' => [
                                    'label' => 'Razón social',
                                    'type' => 'text',
                                    'value' => '',
                                    'placeholder' => 'Nano motor S.L.',
                                ],
                            ],
                            [
                                'code' => [
                                    'label' => 'Código',
                                    'type' => 'text',
                                    'value' => '',
                                    'placeholder' => '92456132',
                                ],
                                'cif' => [
                                    'label' => 'CIF',
                                    'type' => 'text',
                                    'value' => '',
                                    'placeholder' => 'S3807123I',
                                ],
                            ],
                            [
                                'province_id' => [
                                    'label' => 'Provincia',
                                    'type' => 'select',
                                    'value' => '',
                                    'options' => $provinces,
                                    'optionAttribute' => 'name',
                                ],
                                'zone_manager_id' => [
                                    'label' => 'Responsable de zona',
                                    'type' => 'select',
                                    'value' => '',
                                    'options' => $zoneManagers,
                                    'optionAttribute' => 'name',
                                ],
                            ],
                            [
                                'email' => [
                                    'label' => 'Correo electrónico',
                                    'type' => 'text',
                                    'value' => '',
                                    'placeholder' => 'nanomotor@gmail.com',
                                ],
                                'phone' => [
                                    'label' => 'Télefono',
                                    'type' => 'text',
                                    'value' => '+34 ',
                                    'placeholder' => '+34 609055833',
                                ],
                            ],
                        ]" :errors="$errors" :submitText="'Crear concesionario'"
                            :cancelButtonPath="'/dealerships'" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
