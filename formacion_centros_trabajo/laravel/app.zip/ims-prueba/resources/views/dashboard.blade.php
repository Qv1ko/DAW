<x-app-layout>
    <div class="m-4 grid grid-cols-3 grid-rows-3 gap-4">
        {{-- @dd($maxCapital->name); --}}
        <x-card :styles="'text-green-500 flex items-center'" :title="$maxCapital->dealership->commercial_name" :label="'Concesionario con mayor precio neto'">
            <x-icons.treding-up :w="'52'" :h="'52'" />
            {{ number_format($maxCapital->total_capital, 0, ',', '.') }} €
        </x-card>
        <x-card :styles="'text-red-500 flex items-center'" :title="$minCapital->dealership->commercial_name" :label="'Concesionario con menor precio neto'">
            <x-icons.treding-down :w="'52'" :h="'52'" />
            {{ number_format($minCapital->total_capital, 0, ',', '.') }} €
        </x-card>
        <x-card :styles="'flex items-center'" :title="$maxCount['province_name']" :label="'Provincia con más vehículos'">
            {{ $maxCount['vehicle_count'] }}
        </x-card>
        <div class="col-span-2 row-span-2 bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
            <div id="bar-chart" class="w-full h-[400px]"
                data-chart="{{ json_encode(['title' => 'Valor total (miles de €) de los vehículos de cada marca', 'data' => $barData]) }}">
            </div>
        </div>
        <div class="row-span-2 col-start-3 bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
            <div id="pie-chart" class="w-full min-h-[400px]"
                data-chart="{{ json_encode(['title' => 'Número de vehículos disponibles en cada concesionario', 'label' => 'Nº de vehículos', 'data' => $pieData]) }}">
            </div>
        </div>
    </div>
</x-app-layout>
@vite(['resources/js/echarts.js', 'resources/js/barChart.js', 'resources/js/pieChart.js'])
