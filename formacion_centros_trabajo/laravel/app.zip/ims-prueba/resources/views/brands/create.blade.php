<x-app-layout>
    <div class="py-6 bg-gray-100 dark:bg-gray-900">
        <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6 text-gray-800 dark:text-gray-100">
                    <div class="w-full overflow-x-auto">
                        <h1 class="text-center text-xl mb-4">Nueva marca</h1>
                        <x-form :actionRoute="'brands.store'" :structure="[
                            [
                                'name' => [
                                    'label' => 'Marca',
                                    'type' => 'text',
                                    'value' => '',
                                    'placeholder' => 'Mercedes Benz',
                                ],
                            ],
                        ]" :errors="$errors" :submitText="'Crear marca'"
                            :cancelButtonPath="'/brands'" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
