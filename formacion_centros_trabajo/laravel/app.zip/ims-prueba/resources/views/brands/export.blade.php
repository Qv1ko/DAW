<table>
    <thead>
        <tr>
            @foreach ($headers as $head)
                <th>{{ $head }}</th>
            @endforeach
        </tr>
    </thead>
    <tbody>
        @foreach ($brands as $brand)
            <tr>
                <td>{{ $brand->id }}</td>
                <td>{{ $brand->name}}</td>
            </tr>
        @endforeach
    </tbody>
</table>
