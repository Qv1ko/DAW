<x-app-layout>
    @if (session('status'))
        <x-alert :text="session('status')" />
    @endif
    <div class="py-6 bg-gray-100 dark:bg-gray-900">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
                <div class="p-6 text-gray-800 dark:text-gray-100">
                    <div class="w-full overflow-x-auto">
                        <x-management-table :route="'/brands'" :search="$search" :exportRoute="'brands.export'" :importRoute="'brands.import'"
                            :createRoute="'brands.create'" :model="'marca'" :attributeList="[
                                'name' => [
                                    'head' => 'Marca',
                                    'sortBy' => 'name',
                                    'type' => 'text',
                                    'styles' => 'text-left',
                                ],
                                'vehiclesCount' => [
                                    'head' => 'Nº vehículos',
                                    'type' => 'text',
                                    'styles' => 'text-center',
                                ],
                            ]" :items="$brands" :editRoute="'brands.edit'"
                            :deleteInfo="[
                                'text' => 'Está seguro de que quieres eliminar la marca ',
                                'attribute' => 'name',
                            ]" :deleteRoute="'brands.destroy'" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
