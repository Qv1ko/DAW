<form id="importForm" action="{{ route($route) }}" method="post" enctype="multipart/form-data" class="flex">
    @csrf
    @method('PUT')

    <input type="file" id="fileInput" name="import_file" accept=".xls,.xlsx,.csv" style="display: none;" required>
    <button type="button" id="uploadButton"
        class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-1 mx-1 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"><x-icons.import />Importar</button>
</form>
@vite(['resources/js/importButton.js'])
