<nav aria-label="pagination" class="my-2 me-1">
    {{ $slot }}
</nav>
