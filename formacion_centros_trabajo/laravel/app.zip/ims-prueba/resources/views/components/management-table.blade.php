<div class="relative overflow-x-auto shadow-sm sm:rounded-lg">
    @if ($items)
        <div class="flex justify-between my-2 ms-1">
            <x-search-bar :route="$route" :model="$model" :search="$search" />
            <div class="flex align-center">
                @can('export')
                    <x-export-button :route="$exportRoute" />
                @endcan
                @can('import')
                    <x-import-button :route="$importRoute" />
                @endcan
                @can('create')
                    <x-create-button :route="$createRoute" :model="$model" />
                @endcan
            </div>
        </div>
        <table class="w-full text-sm text-gray-500 dark:text-gray-400">
            <thead class="text-md text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    @foreach ($attributeList as $attribute => $attributeValues)
                        <th scope="col" class="px-4 py-4 {{ $attributeValues['styles'] }}">
                            @if (isset($attributeValues['sortBy']))
                                @sortablelink($attributeValues['sortBy'], $attributeValues['head'])
                            @else
                                {{ $attributeValues['head'] }}
                            @endif
                        </th>
                    @endforeach
                    @canany(['update', 'delete'])
                        <th scope="col" class="px-4 py-4"></th>
                    @endcan
                </tr>
            </thead>
            <tbody>
                @foreach ($items as $item)
                    <tr
                        class="items-center align-middle odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700 border-gray-200">
                        @foreach ($attributeList as $attribute => $attributeValues)
                            <td class="px-4 py-2 {{ $attributeValues['styles'] }}">
                                @switch($attributeValues['type'])
                                    @case('text')
                                        {{ $item->$attribute }}
                                    @break

                                    @case('color')
                                        <x-icons.color :color="$item->$attribute" />
                                    @break

                                    @default
                                @endswitch
                            </td>
                        @endforeach
                        @canany(['update', 'delete'])
                            <td class="px-4 py-1">
                                <div class="flex items-center justify-end align-middle">
                                    @can('update')
                                        <x-edit-button :id="$item->id" :route="$editRoute" />
                                    @endcan
                                    @can('delete')
                                        <x-delete-button :id="$item->id" :text="'¿' . $deleteInfo['text'] . $item[$deleteInfo['attribute']] . '?'" :route="$deleteRoute" />
                                    @endcan
                                </div>
                            </td>
                        @endcan
                    </tr>
                @endforeach
            </tbody>
        </table>
        <x-pagination>
            {{ $items->withQueryString()->links() }}
        </x-pagination>
    @else
        <div>
            No hay datos
        </div>
    @endif
</div>
