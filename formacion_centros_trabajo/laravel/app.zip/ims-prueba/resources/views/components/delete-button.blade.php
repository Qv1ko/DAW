<button data-modal-target="confirm-modal-{{ $id }}" data-modal-toggle="confirm-modal-{{ $id }}"
    class="text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm p-2 text-center inline-flex items-center mx-1 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800"
    type="button">
    <x-icons.trash />
    <span class="sr-only">Eliminar</span>
</button>

<x-confirm-modal :id="$id" :text="$text" :route="$route" />
