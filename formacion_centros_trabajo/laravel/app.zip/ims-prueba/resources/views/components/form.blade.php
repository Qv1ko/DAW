@props([
    'actionRoute' => '#',
    'parameter' => '',
    'method' => 'post',
    'structure' => [],
    'errors' => [],
    'submitText' => 'Enviar',
    'cancelButtonPath' => '/dashboard',
])

<form action="{{ Route($actionRoute, $parameter) }}" class="max-w-lg mx-auto" method="post">
    @csrf
    @method($method)

    @foreach ($structure as $rowItems)
        <div class="grid md:grid-cols-{{ count($rowItems) }} md:gap-6">
            @foreach ($rowItems as $item => $itemValues)
                <div class="mb-5">
                    <label for="{{ $item }}"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">{{ $itemValues['label'] }}</label>
                    @switch($itemValues['type'])
                        @case('text')
                            <input type="text" name="{{ $item }}"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 @error($item) !bg-red-50 !border-red-500 @enderror"
                                placeholder="{{ $itemValues['placeholder'] }}" value="{{ old($item, $itemValues['value']) }}" />
                            @error($item)
                                <p class="mt-2 text-sm text-red-600 dark:text-red-500">
                                    {{ $errors->get($item)[0] }}
                                </p>
                            @enderror
                        @break

                        @case('color')
                            <div class="flex">
                                <span
                                    class="inline-flex items-center px-3 text-sm text-gray-900 bg-gray-200 border border-e-0 border-gray-300 rounded-s-md dark:bg-gray-600 dark:text-gray-400 dark:border-gray-600 @error($item) !bg-red-50 !border-red-500 @enderror">
                                    <x-icons.color :w="'24'" :h="'24'" :color="old($item, $itemValues['value'])" />
                                </span>
                                <input type="text" id="{{ $item }}" value="{{ old($item, $itemValues['value']) }}"
                                    name="{{ $item }}"
                                    oninput="document.getElementById('color-icon').setAttribute('fill', this.value)"
                                    class="rounded-none rounded-e-lg bg-gray-50 border border-gray-300 text-gray-900 focus:ring-blue-500 focus:border-blue-500 block flex-1 min-w-0 w-full text-sm p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 @error($item) !bg-red-50 !border-red-500 @enderror" />
                            </div>
                            @error($item)
                                <p class="mt-2 text-sm text-red-600 dark:text-red-500">
                                    {{ $errors->get($item)[0] }}
                                </p>
                            @enderror
                        @break

                        @case('select')
                            <select name="{{ $item }}"
                                class="select2 @error($item) error @enderror">
                                <option value="">{{ $itemValues['label'] }}</option>
                                @foreach ($itemValues['options'] as $option)
                                    <option value="{{ strtolower($option->id) }}"
                                        {{ (is_null(old($item)) && $itemValues['value'] == $option->id) || (!is_null(old($item)) && old($item) == $option->id) ? 'selected' : '' }}>
                                        {{ $option[$itemValues['optionAttribute']] }}
                                    </option>
                                @endforeach
                            </select>
                            @error($item)
                                <p class="mt-2 text-sm text-red-600 dark:text-red-500">
                                    {{ $errors->get($item)[0] }}
                                </p>
                            @enderror
                        @break

                        @default
                    @endswitch
                </div>
            @endforeach
        </div>
    @endforeach
    <div class="flex gap-6">
        <button type="submit"
            class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm block w-full sm:w-auto px-5 py-2 mb-1 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">{{ $submitText }}</button>
        <x-cancel-button :route="$cancelButtonPath" />
    </div>
</form>
@vite(['resources/css/select2.css', 'resources/js/select2.js', 'resources/js/select2Component.js'])
