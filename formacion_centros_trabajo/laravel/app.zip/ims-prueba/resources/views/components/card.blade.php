@props(['styles', 'title', 'label'])

<div
    class=" bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg flex flex-col items-center justify-center">
    <p class="mb-2 text-5xl font-extrabold {{ $styles }}">
        {{ $slot }}
    </p>
    <p class="text-gray-500 text-3xl dark:text-gray-400">{{ $title }}</p>
    <p class="text-gray-500 text-lg dark:text-gray-400 ">{{ $label }}</p>
</div>
