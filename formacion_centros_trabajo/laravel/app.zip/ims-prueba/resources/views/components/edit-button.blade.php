<a href="{{ route($route, $id) }}"
    class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm p-2 text-center inline-flex items-center mx-1 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
    <x-icons.edit />
    <span class="sr-only">Editar</span>
</a>
