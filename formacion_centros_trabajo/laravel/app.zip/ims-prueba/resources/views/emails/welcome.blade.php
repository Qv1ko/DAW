<x-mail::message>
# Bienvenido a IMS
<x-mail::panel>
    Su usuario se registrado en IMS con éxito.
</x-mail::panel>
<x-mail::button :url="route('dashboard')">
    Accede a IMS
</x-mail::button>
</x-mail::message>
