let chartDom = document.getElementById('bar-chart');
let data = JSON.parse(chartDom.getAttribute("data-chart"));
let myChart = echarts.init(chartDom);
let option;

option = {
    title: [{
        text: data.title,
        left: 'center',
        top: '4%',
    }],
    xAxis: {
        type: 'category',
        data: data.data.map((brand) => brand.brand.name),
        axisLabel: {
            interval: 0,
            rotate: 30
        }
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        label: {
            show: true,
            position: 'inside'
        },
        data: data.data.map((brand) => brand.total.toFixed(3)),
        type: 'bar'
    }]
};

option && myChart.setOption(option);
