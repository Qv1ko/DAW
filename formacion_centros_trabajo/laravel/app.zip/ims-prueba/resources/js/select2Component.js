$(document).ready(function() {
    $(".select2").select2({
        allowClear: true,
        minimumResultsForSearch: 1,
        dropdownCssClass: "custom-dropdown",
        containerCssClass: "custom-container"
    });
});