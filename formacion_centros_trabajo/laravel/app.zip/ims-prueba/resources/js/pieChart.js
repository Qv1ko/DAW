let chartDom = document.getElementById('pie-chart');
let data = JSON.parse(chartDom.getAttribute("data-chart"));
let myChart = echarts.init(chartDom);
let option;

option = {
    title: [{
        text: data.title,
        left: 'center',
        top: '4%',
    }],
    tooltip: {
        trigger: 'item'
    },
    series: [{
        name: data.label,
        type: 'pie',
        radius: ['35%', '70%'],
        avoidLabelOverlap: false,
        itemStyle: {
            borderRadius: 10,
            borderColor: '#fff',
            borderWidth: 2
        },
        label: {
            show: false,
            position: 'center'
        },
        emphasis: {
            label: {
                show: true,
                fontSize: 16,
                fontWeight: 'bold'
            }
        },
        labelLine: {
            show: false
        },
        data: data.data,
    }]
};

option && myChart.setOption(option);
