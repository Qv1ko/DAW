<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Illuminate\Http\Request;
use App\Exports\BrandsExport;
use App\Imports\BrandsImport;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\StoreBrandRequest;
use App\Http\Requests\UpdateBrandRequest;

class BrandController extends Controller
{
    protected $indexPage = "/brands";

    public function index(Request $req)
    {
        $search = $req->search;

        $brands = Brand::where(function ($query) use ($search) {
            $query->where('name', 'like', "%$search%");
        })->sortable('name')->paginate(12);

        return view('brands.index', compact('brands', 'search'));
    }

    public function show()
    {
        return redirect($this->indexPage);
    }

    public function create()
    {
        return view('brands.create');
    }

    public function store(StoreBrandRequest $req)
    {
        Brand::create($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->name, 'creada'));
    }

    public function edit(Brand $brand)
    {
        return view('brands.edit', compact('brand'));
    }

    public function update(UpdateBrandRequest $req, $id)
    {
        Brand::find($id)->update($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->name, 'actualizada'));
    }

    public function destroy($id)
    {
        $brand = Brand::find($id);

        if ($brand) {
            $name = $brand->name;
            $brand->delete();
        }

        return redirect($this->indexPage)->with('status', $this::alertMessage($name, 'eliminada'));
    }

    public function export()
    {
        return Excel::download(new BrandsExport, 'marcas_ims.xlsx');
    }

    public function import(Request $req)
    {
        Excel::import(new BrandsImport, $req->file('import_file'));
        return redirect($this->indexPage)->with('status', 'Archivo importado con éxito');
    }

    private static function alertMessage($identifier, $action)
    {
        return 'Marca ' . $identifier . ' ' . $action . ' con éxito';
    }
}
