<?php

namespace App\Http\Controllers;

use App\Models\ZoneManager;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Exports\ZoneManagersExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\StoreZoneManagerRequest;
use App\Http\Requests\UpdateZoneManagerRequest;
use App\Imports\ZoneManagersImport;

class ZoneManagerController extends Controller
{
    protected $indexPage = "/zoneManagers";

    public function index(Request $req)
    {
        $search = $req->search;

        $zoneManagers = ZoneManager::where(function ($query) use ($search) {
            $query->where('name', 'like', "%$search%");
        })->sortable('name')->paginate(12);

        return view('zoneManagers.index', compact('zoneManagers', 'search'));
    }

    public function show()
    {
        return redirect($this->indexPage);
    }

    public function create()
    {
        return view('zoneManagers.create');
    }

    public function store(StoreZoneManagerRequest $req)
    {
        ZoneManager::create($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->name, 'creado'));
    }

    public function edit(ZoneManager $zoneManager)
    {
        return view('zoneManagers.edit', compact('zoneManager'));
    }

    public function update(UpdateZoneManagerRequest $req, $id)
    {
        ZoneManager::find($id)->update($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->name, 'actualizado'));
    }

    public function destroy($id)
    {
        $zoneManager = ZoneManager::find($id);

        if ($zoneManager) {
            $name = $zoneManager->name;
            $zoneManager->delete();
        }

        return redirect($this->indexPage)->with('status', $this::alertMessage($name, 'eliminado'));
    }

    public function export()
    {
        return Excel::download(new ZoneManagersExport, 'responsables-zona_ims.xlsx');
    }

    public function import(Request $req)
    {
        Excel::import(new ZoneManagersImport, $req->file('import_file'));
        return redirect($this->indexPage)->with('status', 'Archivo importado con éxito');
    }

    private static function alertMessage($identifier, $action)
    {
        return 'Responsable de zona ' . $identifier . ' ' . $action . ' con éxito';
    }
}
