<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use App\Models\Province;
use App\Models\Dealership;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $maxCapital = Vehicle::with('dealership')->select('*', DB::raw('SUM(price) AS total_capital'))->groupBy('dealership_id')->orderBy('total_capital', 'desc')->first();

        $minCapital = Vehicle::with('dealership')->select('*', DB::raw('SUM(price) AS total_capital'))->groupBy('dealership_id')->orderBy('total_capital', 'asc')->first();

        $provinces = Province::with('dealerships.vehicles')->get();
        $maxCount = $provinces->map(function ($province) {
            return [
                'province_name' => $province->name,
                'vehicle_count' => $province->dealerships->sum(function ($dealership) {
                    return $dealership->vehicles->count();
                }),
            ];
        })->sortByDesc('vehicle_count')->values()->first();

        $barData = Vehicle::with('brand')->select('brand_id', DB::raw('ROUND(SUM(price) / 1000000, 3) as total'))->groupBy('brand_id')->orderBy('total')->get();

        $dealerships = Dealership::orderBy('commercial_name')->get();
        $pieData = [];
        foreach ($dealerships as $dealership) {
            array_push($pieData, [
                'value' => $dealership->vehiclesCount,
                'name' => $dealership->commercial_name,
            ]);
        }

        return view('dashboard', compact('maxCapital', 'minCapital', 'maxCount', 'barData', 'pieData'));
    }
}
