<?php

namespace App\Http\Controllers;

use App\Models\Province;
use App\Models\Dealership;
use App\Models\ZoneManager;
use Illuminate\Http\Request;
use App\Exports\DealershipsExport;
use App\Imports\DealershipsImport;
use Illuminate\Routing\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\StoreDealershipRequest;
use App\Http\Requests\UpdateDealershipRequest;

class DealershipController extends Controller
{
    private $indexPage = "/dealerships";

    public function index(Request $req)
    {
        $search = $req->search;

        $dealerships = Dealership::where(function ($query) use ($search) {
            $query->where('commercial_name', 'like', "%$search%")
                ->orWhere('company_reason', 'like', "%$search%")
                ->orWhere('cif', 'like', "%$search%")
                ->orWhere('email', 'like', "%$search%")
                ->orWhere('phone', 'like', "%$search%")
                ->orWhere('code', 'like', "%$search%")
                ->orWhereHas('province', function ($query) use ($search) {
                    $query->where('name', 'like', "%$search%");
                })
                ->orWhereHas('zoneManager', function ($query) use ($search) {
                    $query->where('name', 'like', "%$search%");
                });
        })->sortable('commercial_name')->paginate(12);

        return view('dealerships.index', compact('dealerships', 'search'));
    }

    public function show()
    {
        return redirect($this->indexPage);
    }

    public function create()
    {
        $provinces = Province::orderBy('name', 'asc')->get();
        $zoneManagers = ZoneManager::orderBy('name', 'asc')->get();
        return view('dealerships.create', compact('provinces', 'zoneManagers'));
    }

    public function store(StoreDealershipRequest $req)
    {
        Dealership::create($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->comercial_name, 'creado'));
    }

    public function edit(Dealership $dealership)
    {
        $provinces = Province::orderBy('name', 'asc')->get();
        $zoneManagers = ZoneManager::orderBy('name', 'asc')->get();
        return view('dealerships.edit', compact('dealership', 'provinces', 'zoneManagers'));
    }

    public function update(UpdateDealershipRequest $req, $id)
    {
        Dealership::find($id)->update($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->commercial_name, 'actualizado'));
    }

    public function destroy($id)
    {
        $dealership = Dealership::find($id);

        if ($dealership) {
            $commercial_name = $dealership->commercial_name;
            $dealership->delete();
        }

        return redirect($this->indexPage)->with('status', $this::alertMessage($commercial_name, 'eliminado'));
    }

    public function export()
    {
        return Excel::download(new DealershipsExport, 'concesionarios_ims.xlsx');
    }

    public function import(Request $req)
    {
        Excel::import(new DealershipsImport, $req->file('import_file'));
        return redirect($this->indexPage)->with('status', 'Archivo importado con éxito');
    }

    private static function alertMessage($identifier, $action)
    {
        return 'Concesionario ' . $identifier . ' ' . $action . ' con éxito';
    }
}
