<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Vehicle;
use App\Models\Dealership;
use Illuminate\Http\Request;
use App\Exports\VehiclesExport;
use App\Imports\VehiclesImport;
use Illuminate\Routing\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\StoreVehicleRequest;
use App\Http\Requests\UpdateVehicleRequest;

class VehicleController extends Controller
{
    private $indexPage = "/vehicles";

    public function index(Request $req)
    {
        $search = $req->search;

        $vehicles = Vehicle::where(function ($query) use ($search) {
            $query->where('vin', 'like', "%$search%")
                ->orWhereHas('brand', function ($query) use ($search) {
                    $query->where('name', 'like', "%$search%");
                })
                ->orWhere('model', 'like', "%$search%")
                ->orWhere('version', 'like', "%$search%")
                ->orWhereHas('dealership', function ($query) use ($search) {
                    $query->where('commercial_name', 'like', "%$search%");
                });
        })->sortable(['id' => 'desc'])->paginate(12);

        return view('vehicles.index', compact('vehicles', 'search'));
    }

    public function show()
    {
        return redirect($this->indexPage);
    }

    public function create()
    {
        $brands = Brand::orderBy('name', 'asc')->get();
        $dealerships = Dealership::orderBy('commercial_name', 'asc')->get();
        return view('vehicles.create', compact('brands', 'dealerships'));
    }

    public function store(StoreVehicleRequest  $req)
    {
        Vehicle::create($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->vin, 'creado'));
    }

    public function edit(Vehicle $vehicle)
    {
        $brands = Brand::orderBy('name', 'asc')->get();
        $dealerships = Dealership::orderBy('commercial_name', 'asc')->get();
        return view('vehicles.edit', compact('vehicle', 'brands', 'dealerships'));
    }

    public function update(UpdateVehicleRequest $req, $id)
    {
        Vehicle::find($id)->update($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->vin, 'actualizado'));
    }

    public function destroy($id)
    {
        $vehicle = Vehicle::find($id);

        if ($vehicle) {
            $vin = $vehicle->vin;
            $vehicle->delete();
        }

        return redirect($this->indexPage)->with('status', $this::alertMessage($vin, 'eliminado'));
    }

    public function export()
    {
        return Excel::download(new VehiclesExport, 'vehiculos_ims.xlsx');
    }

    public function import(Request $req)
    {
        Excel::import(new VehiclesImport, $req->file('import_file'));
        return redirect($this->indexPage)->with('status', 'Archivo importado con éxito');
    }

    private static function alertMessage($identifier, $action)
    {
        return 'Vehículo con VIN ' . $identifier . ' ' . $action . ' con éxito';
    }
}
