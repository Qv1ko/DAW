<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthApiController extends Controller
{
    public function login(Request $req)
    {
        $req->validate(['email' => ['required', 'exists:users,email', 'email'], 'password' => ['required']]);

        $user = User::where('email', $req->email)->first();

        if (!$user || !Hash::check($req->password, $user->password)) {
            return ['message' => 'El usuario o la contraseña no coinciden', 'status' => 401];
        }

        $token = $user->createToken($user->name);

        return ['user' => $user, 'token' => $token->plainTextToken];
    }

    public function logout(Request $req)
    {
        $req->user()->tokens()->delete();
        return ['message' => 'Se ha cerrado sesión correctamente'];
    }
}
