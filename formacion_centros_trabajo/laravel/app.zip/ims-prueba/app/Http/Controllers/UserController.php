<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Exports\UsersExport;
use App\Imports\UsersImport;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;

class UserController extends Controller
{
    protected $indexPage = "/users";

    public function index(Request $req)
    {
        $search = $req->search;

        $users = User::where(function ($query) use ($search) {
            $query->where('name', 'like', "%$search%");
        })->sortable('name')->paginate(12);

        return view('users.index', compact('users', 'search'));
    }

    public function show()
    {
        return redirect($this->indexPage);
    }

    public function create()
    {
        return view('users.create');
    }

    public function store(StoreUserRequest $req)
    {
        User::create($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->name, 'creada'));
    }

    public function edit(User $brand)
    {
        return view('users.edit', compact('brand'));
    }

    public function update(UpdateUserRequest $req, $id)
    {
        User::find($id)->update($req->validated());
        return redirect($this->indexPage)->with('status', $this::alertMessage($req->name, 'actualizada'));
    }

    public function destroy($id)
    {
        $brand = User::find($id);

        if ($brand) {
            $name = $brand->name;
            $brand->delete();
        }

        return redirect($this->indexPage)->with('status', $this::alertMessage($name, 'eliminada'));
    }

    public function export()
    {
        return Excel::download(new UsersExport, 'usuarios_ims.xlsx');
    }

    public function import(Request $req)
    {
        Excel::import(new UsersImport, $req->file('import_file'));
        return redirect($this->indexPage)->with('status', 'Archivo importado con éxito');
    }

    private static function alertMessage($identifier, $action)
    {
        return 'Usuario ' . $identifier . ' ' . $action . ' con éxito';
    }
}
