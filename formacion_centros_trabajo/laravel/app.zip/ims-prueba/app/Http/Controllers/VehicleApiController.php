<?php

namespace App\Http\Controllers;

use App\Models\Vehicle;
use App\Http\Requests\StoreVehicleRequest;
use App\Http\Requests\UpdateVehicleRequest;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Routing\Controllers\HasMiddleware;

class VehicleApiController extends Controller implements HasMiddleware
{
    public static function middleware()
    {
        return [new Middleware('auth:sanctum', except: ['index', 'show'])];
    }

    public function index()
    {
        $vehicles = Vehicle::all();

        if ($vehicles->isEmpty()) {
            return response()->json(['message' => 'No hay vehículos'], 404);
        }

        return response()->json($vehicles, 200);
    }

    public function show($id)
    {
        $vehicle = Vehicle::find($id);

        if (!$vehicle) {
            return response()->json(['message' => 'Vehículo no encontrado'], 404);
        }

        return response()->json($vehicle, 200);
    }

    public function store(StoreVehicleRequest  $req)
    {
        $vehicle = Vehicle::create($req->validated());
        return response()->json(['message' => "Vehículo con VIN $req->vin se ha creado con éxito", 'item' => $vehicle], 200);
    }

    public function update(UpdateVehicleRequest $req, $id)
    {
        $vehicle = Vehicle::findOrFail($id);
        $vehicle->update($req->validated());

        return response()->json(['message' => "Vehículo con VIN $req->vin se ha actualizado con éxito", 'item' => $vehicle], 200);
    }

    public function destroy($id)
    {
        $vehicle = Vehicle::find($id);

        if (!$vehicle) {
            return response()->json(['message' => "Vehículo no encontrado"], 404);
        }

        $vin = $vehicle->vin;
        $vehicle->delete();

        return response()->json(['message' => "Vehículo con VIN $vin de ha eliminado con éxito"], 200);
    }
}
