<?php

namespace App\Http\Requests;

use App\Models\Brand;
use App\Models\Dealership;
use App\Models\Vehicle;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class StoreVehicleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'vin' => ['required', Rule::unique(Vehicle::class, 'vin'), 'regex:/^(?<wmi>[A-HJ-NPR-Za-hj-npr-z\d]{3})(?<vds>[A-HJ-NPR-Za-hj-npr-z\d]{5})(?<check>[\dXx])(?<vis>(?<year>[A-HJ-NPR-Za-hj-npr-z\d])(?<plant>[A-HJ-NPR-Za-hj-npr-z\d])(?<seq>[A-HJ-NPR-Za-hj-npr-z\d]{6}))$/'],
            'brand_id' => ['nullable', Rule::exists(Brand::class, 'id')],
            'model' => ['required', 'min:1', 'max:35'],
            'version' => ['nullable', 'max:50'],
            'external_color' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'dealership_id' => ['nullable', Rule::exists(Dealership::class, 'id')],
            'price' => ['required', 'regex:/^[0-9]+([.,][0-9]{1,2})?/'],
        ];
    }
}
