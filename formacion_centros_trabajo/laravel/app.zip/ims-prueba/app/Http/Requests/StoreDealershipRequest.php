<?php

namespace App\Http\Requests;

use App\Models\Dealership;
use App\Models\Province;
use App\Models\ZoneManager;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class StoreDealershipRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'commercial_name' => ['required', Rule::unique(Dealership::class, 'commercial_name'), 'min:2', 'max:100'],
            'company_reason' => ['required', Rule::unique(Dealership::class, 'company_reason'), 'min:5', 'max:100'],
            'cif' => ['required', Rule::unique(Dealership::class, 'cif'),'regex:/^([AaBbCcDdEeFfGgHhJjKkLlMmNnPpQqRrSsUuVvWw])(\d{7})([0-9A-Ja-j])$/'],
            'email' => ['required', Rule::unique(Dealership::class, 'email'),'regex:/^[\w\.]+@([\w]+\.)+[\w]{2,4}$/'],
            'phone' => ['required', Rule::unique(Dealership::class, 'phone'),'regex:/^(\+?34\s?)?[6-9][0-9]{8}$/'],
            'code' => ['required', Rule::unique(Dealership::class, 'code'),'regex:/^[0-9]{8}$/'],
            'province_id' => ['nullable', Rule::exists(Province::class, 'id')],
            'zone_manager_id' => ['nullable', Rule::exists(ZoneManager::class, 'id')],
        ];
    }
}
