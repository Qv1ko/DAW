<?php

namespace App\Exports;

use App\Models\Brand;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class BrandsExport implements FromView
{
    public function view(): View
    {
        return view('brands.export', [
            'headers' => [
                'ID',
                'Nombre',
            ],
            'brands' => Brand::all(),
        ]);
    }
}
