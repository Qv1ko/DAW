<?php

namespace App\Exports;

use App\Models\ZoneManager;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class ZoneManagersExport implements FromView
{
    public function view(): View
    {
        return view('zoneManagers.export', [
            'headers' => [
                'ID',
                'Nombre'
            ],
            'zoneManagers' => ZoneManager::all(),
        ]);
    }
}
