<?php

namespace App\Exports;

use App\Models\Dealership;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class DealershipsExport implements FromView
{
    public function view(): View
    {
        return view('dealerships.export', [
            'headers' => [
                'ID',
                'Nombre comercial',
                'Razón social',
                'CIF',
                'Email',
                'Télefono',
                'Código',
                'Provincia',
                'Responsable de zona'
            ],
            'dealerships' => Dealership::all(),
        ]);
    }
}
