<?php

namespace App\Exports;

use App\Models\Vehicle;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class VehiclesExport implements FromView
{
    public function view(): View
    {
        return view('vehicles.export', [
            'headers' => [
                'ID',
                'VIN',
                'Marca',
                'Modelo',
                'Versión',
                'Color externo',
                'Concesionario',
                'Precio euros',
            ],
            'vehicles' => Vehicle::all(),
        ]);
    }
}
