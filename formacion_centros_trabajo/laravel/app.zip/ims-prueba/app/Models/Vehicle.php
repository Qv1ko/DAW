<?php

namespace App\Models;

use App\Models\Brand;
use App\Models\Dealership;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Kyslik\ColumnSortable\Sortable;

class Vehicle extends Model
{
    use HasFactory, Sortable;

    public $timestamps = false;

    protected $fillable = [
        'vin',
        'brand_id',
        'model',
        'version',
        'external_color',
        'dealership_id',
        'price',
    ];

    public $sortable = [
        'id',
        'vin',
        'model',
        'price',
    ];

    public function vin(): Attribute
    {
        return Attribute::make(
            get: function ($vin) {
                return $vin;
            },
            set: function ($vin) {
                return strtoupper($vin);
            }
        );
    }

    public function model(): Attribute
    {
        return Attribute::make(
            get: function ($model) {
                return $model;
            },
            set: function ($model) {
                return strtoupper($model);
            }
        );
    }

    public function version(): Attribute
    {
        return Attribute::make(
            get: function ($version) {
                return $version;
            },
            set: function ($version) {
                return $version  !== "" ? strtoupper($version) : null;
            }
        );
    }

    public function externalColor(): Attribute
    {
        return Attribute::make(
            get: function ($external_color) {
                return $external_color;
            },
            set: function ($external_color) {
                return strtoupper($external_color);
            }
        );
    }

    public function price(): Attribute
    {
        return Attribute::make(
            get: function ($price) {
                return $price;
            },
            set: function ($price) {
                return floatval(str_replace(',', '.', $price));
            }
        );
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    public function dealership()
    {
        return $this->belongsTo(Dealership::class);
    }

    public function brandName(): Attribute
    {
        return Attribute::make(
            get: function () {
                if ($this->brand) {
                    return $this->brand->name;
                }
                return null;
            }
        );
    }

    public function dealershipCommercialName(): Attribute
    {
        return Attribute::make(
            get: function () {
                if ($this->dealership) {
                    return $this->dealership->commercial_name;
                }
                return null;
            }
        );
    }

    public function modelVersion(): Attribute
    {
        return Attribute::make(
            get: function () {
                return $this->model . ' ' . $this->version;
            }
        );
    }

    public function euroPrice(): Attribute
    {
        return Attribute::make(
            get: function () {
                return number_format($this->price, 2, ',', '.') . ' €';
            }
        );
    }
}
