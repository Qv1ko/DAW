<?php

namespace App\Models;

use App\Models\Vehicle;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Kyslik\ColumnSortable\Sortable;

class Brand extends Model
{
    use HasFactory, Sortable;

    public $timestamps = false;
    protected $fillable = ['name'];
    public $sortable = ['name'];

    public function vehicles(): HasMany
    {
        return $this->hasMany(Vehicle::class);
    }

    public function vehiclesCount(): Attribute
    {
        return Attribute::make(
            get: function () {
                return $this->vehicles ? count($this->vehicles) : 0;
            }
        );
    }
}
