<?php

namespace App\Models;

use App\Models\Province;
use App\Models\ZoneManager;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Kyslik\ColumnSortable\Sortable;

class Dealership extends Model
{
    use HasFactory, Sortable;

    public $timestamps = false;

    protected $fillable = [
        'commercial_name',
        'company_reason',
        'cif',
        'email',
        'phone',
        'code',
        'province_id',
        'zone_manager_id',
    ];

    public $sortable = [
        'commercial_name',
        'company_reason',
        'cif',
        'email',
        'phone',
        'code',
    ];

    public function cif(): Attribute
    {
        return Attribute::make(
            get: function ($cif) {
                return $cif;
            },
            set: function ($cif) {
                return strtoupper($cif);
            }
        );
    }

    public function email(): Attribute
    {
        return Attribute::make(
            get: function ($email) {
                return $email;
            },
            set: function ($email) {
                return strtolower($email);
            }
        );
    }

    public function province()
    {
        return $this->belongsTo(Province::class);
    }

    public function zoneManager()
    {
        return $this->belongsTo(ZoneManager::class);
    }

    public function vehicles(): HasMany
    {
        return $this->hasMany(Vehicle::class);
    }

    public function provinceName(): Attribute
    {
        return Attribute::make(
            get: function () {
                if ($this->province) {
                    return $this->province->name;
                }
                return null;
            }
        );
    }

    public function zoneManagerName(): Attribute
    {
        return Attribute::make(
            get: function () {
                if ($this->zoneManager) {
                    return $this->zoneManager->name;
                }
                return null;
            }
        );
    }

    public function vehiclesCount(): Attribute
    {
        return Attribute::make(
            get: function () {
                return $this->vehicles ? count($this->vehicles) : 0;
            }
        );
    }
}
