<?php

namespace App\Models;

use App\Models\Dealership;
use Illuminate\Support\Facades\Http;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Province extends Model
{
    use HasFactory;

    public $timestamps = false;

    public function dealerships(): HasMany
    {
        return $this->hasMany(Dealership::class);
    }

    public static function getProvinces(): array
    {
        $response = Http::get('https://servicios.ine.es/wstempus/js/ES/VALORES_VARIABLE/20');

        if (!$response->ok()) {
            return [];
        }

        $data = $response->json();
        $provincesList = [];

        foreach ($data as $item) {
            if (intval($item['Id']) > 0 && intval($item['Id']) < 100) {
                $province = $item['Nombre'];

                if (str_contains($province, ', ')) {
                    $province = implode(' ', array_reverse(explode(', ', $province)));
                }

                if (str_contains($province, '/')) {
                    $province = explode('/', $province)[1];
                }

                array_push($provincesList, $province);
            }
        }

        return $provincesList;
    }
}
