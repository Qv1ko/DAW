<?php

namespace App\Imports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class UsersImport implements ToModel, WithHeadingRow, WithValidation
{
    public function model(array $row)
    {
        return User::updateOrCreate([
            'id' => $row['id'],
        ], [
            'name' => $row['nombre'],
        ]);
    }

    public function rules(): array
    {
        return [
            'id' => ['required', 'integer'],
            // 'nombre' => ['required', 'min:2', 'max:25'],
        ];
    }
}
