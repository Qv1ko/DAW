<?php

namespace App\Imports;

use App\Models\ZoneManager;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class ZoneManagersImport implements ToModel, WithHeadingRow, WithValidation
{
    public function model(array $row)
    {
        return ZoneManager::updateOrCreate([
            'id' => $row['id'],
        ], [
            'name' => $row['nombre'],
        ]);
    }

    public function rules(): array
    {
        return [
            'id' => ['required', 'integer'],
            'nombre' => ['required', 'min:3', 'max:50'],
        ];
    }
}
