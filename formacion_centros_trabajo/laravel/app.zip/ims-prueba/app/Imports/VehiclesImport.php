<?php

namespace App\Imports;

use App\Models\Brand;
use App\Models\Dealership;
use App\Models\Vehicle;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class VehiclesImport implements ToModel, WithHeadingRow, WithValidation
{
    public function model(array $row)
    {
        $brandId = Brand::firstWhere('name', $row['marca']) ? Brand::firstWhere('name', $row['marca'])->id : null;
        $dealershipId = Dealership::firstWhere('commercial_name', $row['concesionario']) ? Dealership::firstWhere('commercial_name', $row['concesionario'])->id : null;

        return Vehicle::updateOrCreate([
            'id' => $row['id'],
        ], [
            'vin' => strtoupper($row['vin']),
            'brand_id' => $brandId,
            'model' => strtoupper($row['modelo']),
            'version' => strtoupper($row['version']),
            'external_color' => strtoupper($row['color_externo']),
            'dealership_id' => $dealershipId,
            'price' => str_replace(',', '.', $row['precio_euros']),
        ]);
    }

    public function rules(): array
    {
        return [
            'id' => ['required', 'integer'],
            'vin' => ['required', 'regex:/^(?<wmi>[A-HJ-NPR-Za-hj-npr-z\d]{3})(?<vds>[A-HJ-NPR-Za-hj-npr-z\d]{5})(?<check>[\dXx])(?<vis>(?<year>[A-HJ-NPR-Za-hj-npr-z\d])(?<plant>[A-HJ-NPR-Za-hj-npr-z\d])(?<seq>[A-HJ-NPR-Za-hj-npr-z\d]{6}))$/'],
            'modelo' => ['required', 'min:1', 'max:35'],
            'version' => ['nullable', 'max:50'],
            'color_externo' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'precio_euros' => ['required', 'regex:/^[0-9]+([.,][0-9]{1,2})?/'],
        ];
    }
}
