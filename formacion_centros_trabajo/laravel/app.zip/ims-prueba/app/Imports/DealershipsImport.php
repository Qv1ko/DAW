<?php

namespace App\Imports;

use App\Models\Province;
use App\Models\Dealership;
use App\Models\ZoneManager;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class DealershipsImport implements ToModel, WithHeadingRow, WithValidation
{
    public function model(array $row)
    {
        $province = Province::firstWhere('name', $row['provincia']);
        $provinceId = $province ? $province->id : null;

        $zoneManager = ZoneManager::firstWhere('name', $row['responsable_de_zona']);
        $zoneManagerId = $zoneManager ? $zoneManager->id : null;

        return Dealership::updateOrCreate([
            'id' => $row['id'],
        ], [
            'commercial_name' => $row['nombre_comercial'],
            'company_reason' => $row['razon_social'],
            'cif' => strtoupper($row['cif']),
            'email' => strtolower($row['email']),
            'phone' => $row['telefono'],
            'code' => $row['codigo'],
            'province_id' => $provinceId,
            'zone_manager_id' => $zoneManagerId,
        ]);
    }

    public function rules(): array
    {
        return [
            'id' => ['required', 'integer'],
            'nombre_comercial' => ['required', 'min:2', 'max:100'],
            'razon_social' => ['required', 'min:5', 'max:100'],
            'cif' => ['required', 'regex:/^([ABCDEFGHJKLMNPQRSUVW])(\d{7})([0-9A-J])$/'],
            'email' => ['required', 'regex:/^[\w\.]+@([\w]+\.)+[\w]{2,4}$/'],
            'telefono' => ['required', 'regex:/^(\+?34\s?)?[6-9][0-9]{8}$/'],
            'codigo' => ['required', 'regex:/^[0-9]{8}$/'],
        ];
    }
}
