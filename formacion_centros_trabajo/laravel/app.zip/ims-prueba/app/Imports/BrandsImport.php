<?php

namespace App\Imports;

use App\Models\Brand;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;

class BrandsImport implements ToModel, WithHeadingRow, WithValidation
{
    public function model(array $row)
    {
        return Brand::updateOrCreate([
            'id' => $row['id'],
        ], [
            'name' => $row['nombre'],
        ]);
    }

    public function rules(): array
    {
        return [
            'id' => ['required', 'integer'],
            'nombre' => ['required', 'min:2', 'max:25'],
        ];
    }
}
