<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\VehicleController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DealershipController;
use App\Http\Controllers\ZoneManagerController;

$exportMiddleware = 'permission:export';
$importMiddleware = 'permission:import';
$createMiddleware = 'permission:create';
$editMiddleware = 'permission:edit';
$deleteMiddleware = 'permission:delete';

$brandsRoute = '/brands';
$dealershipsRoute = '/dealerships';
$vehiclesRoute = '/vehicles';
$zoneManagersRoute = '/zoneManagers';

Route::get('/', [DashboardController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/brands/export', [BrandController::class, 'export'])->middleware(['auth', $exportMiddleware])->name('brands.export');
Route::put('/brands/import', [BrandController::class, 'import'])->middleware(['auth', $importMiddleware])->name('brands.import');
Route::resource($brandsRoute, BrandController::class)->middleware(['auth', $createMiddleware])->only(['create', 'store']);
Route::resource($brandsRoute, BrandController::class)->middleware(['auth', $editMiddleware])->only(['edit', 'update']);
Route::resource($brandsRoute, BrandController::class)->middleware(['auth', $deleteMiddleware])->only(['destroy']);
Route::resource($brandsRoute, BrandController::class)->middleware(['auth', 'verified'])->except(['create', 'store', 'edit', 'update', 'destroy']);

Route::get('/dealerships/export', [DealershipController::class, 'export'])->middleware(['auth', $exportMiddleware])->name('dealerships.export');
Route::put('/dealerships/import', [DealershipController::class, 'import'])->middleware(['auth', $importMiddleware])->name('dealerships.import');
Route::resource($dealershipsRoute, DealershipController::class)->middleware(['auth', $createMiddleware])->only(['create', 'store']);
Route::resource($dealershipsRoute, DealershipController::class)->middleware(['auth', $editMiddleware])->only(['edit', 'update']);
Route::resource($dealershipsRoute, DealershipController::class)->middleware(['auth', $deleteMiddleware])->only(['destroy']);
Route::resource($dealershipsRoute, DealershipController::class)->middleware(['auth', 'verified'])->except(['create', 'store', 'edit', 'update', 'destroy']);

Route::get('/vehicles/export', [VehicleController::class, 'export'])->middleware(['auth', $exportMiddleware])->name('vehicles.export');
Route::put('/vehicles/import', [VehicleController::class, 'import'])->middleware(['auth', $importMiddleware])->name('vehicles.import');
Route::resource($vehiclesRoute, VehicleController::class)->middleware(['auth', $createMiddleware])->only(['create', 'store']);
Route::resource($vehiclesRoute, VehicleController::class)->middleware(['auth', $editMiddleware])->only(['edit', 'update']);
Route::resource($vehiclesRoute, VehicleController::class)->middleware(['auth', $deleteMiddleware])->only(['destroy']);
Route::resource($vehiclesRoute, VehicleController::class)->middleware(['auth', 'verified'])->except(['create', 'store', 'edit', 'update', 'destroy']);

Route::get('/zoneManagers/export', [ZoneManagerController::class, 'export'])->middleware(['auth', $exportMiddleware])->name('zoneManagers.export');
Route::put('/zoneManagers/import', [ZoneManagerController::class, 'import'])->middleware(['auth', $importMiddleware])->name('zoneManagers.import');
Route::resource($zoneManagersRoute, ZoneManagerController::class)->middleware(['auth', $createMiddleware])->only(['create', 'store']);
Route::resource($zoneManagersRoute, ZoneManagerController::class)->middleware(['auth', $editMiddleware])->only(['edit', 'update']);
Route::resource($zoneManagersRoute, ZoneManagerController::class)->middleware(['auth', $deleteMiddleware])->only(['destroy']);
Route::resource($zoneManagersRoute, ZoneManagerController::class)->middleware(['auth', 'verified'])->except(['create', 'store', 'edit', 'update', 'destroy']);

Route::middleware(['auth', 'permission:manage users'])->group(function () {
    Route::resource('/users', UserController::class);
    Route::resource('/roles', RoleController::class);
    Route::resource('/permissions', PermissionController::class);
});

Route::middleware('auth')->group(function () {
    $profileRoute = '/profile';
    Route::get($profileRoute, [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch($profileRoute, [ProfileController::class, 'update'])->name('profile.update');
    Route::delete($profileRoute, [ProfileController::class, 'destroy'])->name('profile.destroy');
});


require __DIR__ . '/auth.php';
