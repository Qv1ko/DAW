@extends("layouts.app")

@section("title", "Laravel 10")

@push("css")
    <style>
        body {
            background-color: #ffdddd;
        }
    </style>
@endpush

@push("css")
    <style>
        body {
            color: blue;
        }
    </style>
@endpush

@section("content")
    <div class="text-center">
        <h1>Bienvenido a la página principal</h1>
        <x-alert2 type="success" class="mb-4">
            <x-slot name="title">
                Titulo de la alerta
            </x-slot>
            Contenido de la alerta
        </x-alert2>
        <p>Hola mundo</p>
    </div>
@endsection
