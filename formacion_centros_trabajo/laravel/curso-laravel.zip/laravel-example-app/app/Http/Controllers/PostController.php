<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\StorePostRequest;
use App\Mail\PostCreatedMail;
use Illuminate\Support\Facades\Mail;

class PostController extends Controller
{
    public function index() {
        $posts = Post::orderBy('id', 'desc')->paginate(10);

        return view("posts.index", [
            'posts' => $posts,
        ]);
    }

    public function create() {
        return view("posts.create");
    }

    public function store(StorePostRequest $req) {
        $post = Post::create($req->all());

        Mail::to('prueba@prueba.com')->send(new PostCreatedMail($post));

        return redirect()->route('posts.index');
    }

    public function show(Post $post) {
        // $this->authorize('published', $post);
        return view("posts.show", compact('post'));
    }

    public function edit(Post $post) {
        // $this->authorize('author', $post);
        return view('posts.edit',compact('post'));
    }

    public function update(Request $req, Post $post) {
        // $this->authorize('author', $post);
        $req->validate([
            'title' => 'required|min:5|max:255',
            'slug' => "required|unique:posts,slug,{$post->id}",
            'category' => 'required',
            'content' => ' required'
        ]);
        $post->update($req->all());
        return redirect()->route('posts.show', $post);
    }

    public function destroy(Post $post) {
        // $this->authorize('author', $post);
        $post->delete();
        return redirect()->route('posts.index');
    }

}
