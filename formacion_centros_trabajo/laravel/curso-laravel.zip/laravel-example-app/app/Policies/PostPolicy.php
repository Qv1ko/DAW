<?php

namespace App\Policies;

use App\Models\Post;
use App\Models\User;

class PostPolicy
{
    /**
     * Create a new policy instance.
     */
    public function author(User $user, Post $post) {
        return $user->id === $post->user_id;
    }

    public function published(?User $user, Post $post) {
        return $post->status == 2;
    }
}
