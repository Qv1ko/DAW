<?php

namespace App\Providers;

use Whitecube\LaravelCookieConsent\Cookie;
use Whitecube\LaravelCookieConsent\CookiesServiceProvider as ServiceProvider;
use Whitecube\LaravelCookieConsent\Facades\Cookies;

class CookiesServiceProvider extends ServiceProvider
{
    /**
     * Define the cookies users should be aware of.
     */
    protected function registerCookies(): void
    {
        // Register Laravel's base cookies under the "required" cookies section:
        Cookies::essentials()
            ->session()
            ->csrf();

        // Register all Analytics cookies at once using one single shorthand method:
        // Cookies::analytics()
        //    ->google(
        //        id:          env('GOOGLE_ANALYTICS_ID'),
        //        anonymizeIp: env('GOOGLE_ANALYTICS_ANONYMIZE_IP'),
        //    );

        // Register custom cookies under the pre-existing "optional" category:
        Cookies::optional()
        ->cookie(function(Cookie $cookie) {
            $cookie->name('darkmode_enabled')       // Defining a cookie
                ->description('Lorem ipsum')        // Adding the cookie's description for display
                ->duration(120);                    // Adding the cookie's lifetime in minutes
        })
        ->cookie(function(Cookie $cookie) {
            $cookie->name('high_contrast_enabled')  // Defining a cookie
                ->description('Lorem ipsum')        // Adding the cookie's description for display
                ->duration(60 * 24 * 365);          // Adding the cookie's lifetime in minutes
        });
    }
}
