<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type' => "info"]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type' => "info"]); ?>
<?php foreach (array_filter((['type' => "info"]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    switch($type) {
        case "info":
            $color = "text-blue-800 rounded-lg bg-blue-50 dark:bg-gray-800 dark:text-blue-400";
            break;

        case "danger":
            $color = "text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400";
            break;

        case "success":
            $color = "text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400";
            break;

        case "warning":
            $color = "text-yellow-800 rounded-lg bg-yellow-50 dark:bg-gray-800 dark:text-yellow-300";
            break;

        case "dark":
            $color = "text-gray-800 rounded-lg bg-gray-50 dark:bg-gray-800 dark:text-gray-300";
            break;

        default:
            $color = "text-blue-800 rounded-lg bg-blue-50 dark:bg-gray-800 dark:text-blue-400";
            break;
    }
?>

<div <?php echo e($attributes->merge(['class' => 'p-4 text-sm' .  $color])); ?> role="alert">
    <span class="font-medium"><?php echo e($title ?? "Alert!"); ?>!</span> <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Proyectos\example-app\resources\views/components/alert.blade.php ENDPATH**/ ?>