<?php echo e($slot); ?>

<?php /**PATH C:\Proyectos\example-app\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>