<div <?php echo e($attributes->merge(['class' => 'p-4 text-sm ' .  $color])); ?> role="alert">
    <span class="font-medium"><?php echo e($title ?? "Alert!"); ?>!</span> <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Proyectos\example-app\resources\views/components/alert2.blade.php ENDPATH**/ ?>