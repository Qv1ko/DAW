<?php $__env->startSection("title", "Laravel 10"); ?>

<?php $__env->startPush("css"); ?>
    <style>
        p {
            max-width: 80ch;
            text-align: justify;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
    <a href="<?php echo e(route('posts.index')); ?>">Volver a posts</a>
    <h1>Titulo: <?php echo e($post->title); ?></h1>
    <p>
        <b>Categoría: <?php echo e($post->category); ?></b>
    </p>
    <p>
        <?php echo e($post->content); ?>

    </p>
    <a href="<?php echo e(route('posts.edit', $post)); ?>">Editar post</a>
    <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit">Eliminar post</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\example-app\resources\views/posts/show.blade.php ENDPATH**/ ?>