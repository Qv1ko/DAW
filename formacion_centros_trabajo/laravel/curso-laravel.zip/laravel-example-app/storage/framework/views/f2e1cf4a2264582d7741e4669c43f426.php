<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent("title", "Curso de Laravel"); ?></title>
    
    

    <?php echo $__env->yieldPushContent("css"); ?>
    <?php echo Whitecube\LaravelCookieConsent\Facades\Cookies::renderScripts(); ?>
</head>
<body>
    <header></header>

    <?php echo $__env->yieldContent("content"); ?>

    <footer></footer>
    <?php echo Whitecube\LaravelCookieConsent\Facades\Cookies::renderView(); ?>
</body>
</html>
<?php /**PATH C:\Proyectos\example-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>