<?php $__env->startSection("title", "Laravel 10"); ?>

<?php $__env->startPush("css"); ?>
    <style>
        body {
            background-color: #ffdddd;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush("css"); ?>
    <style>
        body {
            color: blue;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection("content"); ?>
    <div class="text-center">
        <h1>Bienvenido a la página principal</h1>
        <?php if (isset($component)) { $__componentOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5 = $attributes; } ?>
<?php $component = App\View\Components\Alert2::resolve(['type' => 'success'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert2::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
             <?php $__env->slot('title', null, []); ?> 
                Titulo de la alerta
             <?php $__env->endSlot(); ?>
            Contenido de la alerta
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5)): ?>
<?php $attributes = $__attributesOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5; ?>
<?php unset($__attributesOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5)): ?>
<?php $component = $__componentOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5; ?>
<?php unset($__componentOriginal2a81c3e0bd0367ff1c2023bb70c7d8d5); ?>
<?php endif; ?>
        <p>Hola mundo</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Proyectos\example-app\resources\views/home.blade.php ENDPATH**/ ?>