import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MessagesService } from '../messages.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-messages',
  imports: [CommonModule, FormsModule],
  templateUrl: './add-messages.component.html',
  styleUrl: './add-messages.component.css'
})
export class AddMessagesComponent {
  constructor(public messageService: MessagesService) {}

  message?: string;

  addMessage() {
    this.messageService.add(this.message!);
    this.message = "";
  }
}
