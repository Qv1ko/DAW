export interface Persona {
  nombre: string,
  edad: number,
}