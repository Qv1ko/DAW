import { Component, OnInit } from '@angular/core';
import { Persona } from '../persona'

@Component({
  selector: 'app-contador',
  imports: [],
  templateUrl: './contador.component.html',
  styleUrl: './contador.component.css'
})
export class ContadorComponent implements OnInit {
  numero = 1;

  constructor() {}

  ngOnInit(): void {
  }

  nombre: string = 'Víctor';

  persona: Persona = {
    nombre: "Víctor",
    edad: 20,
  }

  decrement = () => this.numero--;
  increment = () => this.numero++;
}
