import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ContadorComponent } from './contador/contador.component';
import { BotonesComponent } from "./botones/botones.component";
import { FormularioComponent } from "./formulario/formulario.component";
import { BuclesComponent } from './bucles/bucles.component';
import { SwitchComponent } from './switch/switch.component';
import { FormWithTemplatesComponent } from "./form-with-templates/form-with-templates.component";
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { FormularioReactivoComponent } from "./formulario-reactivo/formulario-reactivo.component";
import { ChildrenComponent } from "./children/children.component";
import { AddMessagesComponent } from "./add-messages/add-messages.component";
import { ListMessagesComponent } from "./list-messages/list-messages.component";

@Component({
  selector: 'app-root',
  imports: [FormsModule, AddMessagesComponent, ListMessagesComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  title = 'Curso Angular';
}
