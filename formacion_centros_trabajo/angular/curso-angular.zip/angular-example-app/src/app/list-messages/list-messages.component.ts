import { NgFor } from '@angular/common';
import { Component } from '@angular/core';
import { MessagesService } from '../messages.service';

@Component({
  selector: 'app-list-messages',
  imports: [NgFor],
  templateUrl: './list-messages.component.html',
  styleUrl: './list-messages.component.css'
})
export class ListMessagesComponent {
  constructor(public messageService: MessagesService) {}
}
