import { Component } from '@angular/core';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-formulario',
  imports: [NgIf],
  templateUrl: './formulario.component.html',
  styleUrl: './formulario.component.css'
})
export class FormularioComponent {
  openAlert: boolean = false;
  mostrar_consola(name: string) {
    console.log(name);
    this.openAlert = true;
  }
  borrar_alert() {
    this.openAlert = false;
  }
}
