import { Component } from '@angular/core';
import {CommonModule} from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-form-with-templates',
  imports: [CommonModule, FormsModule],
  templateUrl: './form-with-templates.component.html',
  styleUrl: './form-with-templates.component.css'
})
export class FormWithTemplatesComponent {
  persona = {
    nombre: "",
    edad: "",
  }

  procesar() {
    console.log(this.persona);
  }
}
