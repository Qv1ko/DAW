import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormWithTemplatesComponent } from './form-with-templates.component';

describe('FormWithTemplatesComponent', () => {
  let component: FormWithTemplatesComponent;
  let fixture: ComponentFixture<FormWithTemplatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormWithTemplatesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormWithTemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
