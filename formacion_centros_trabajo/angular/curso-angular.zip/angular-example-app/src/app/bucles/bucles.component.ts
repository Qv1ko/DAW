import { Component } from '@angular/core';
import { NgFor } from '@angular/common';
import { Persona } from '../persona'

@Component({
  selector: 'app-bucles',
  imports: [NgFor],
  templateUrl: './bucles.component.html',
  styleUrl: './bucles.component.css'
})
export class BuclesComponent {
  personas: Persona[] = [
    {nombre: 'Juan', edad: 20},
    {nombre: 'Ana', edad: 25},
    {nombre: 'Luis', edad: 30},
    {nombre: 'María', edad: 35}
  ];
}
