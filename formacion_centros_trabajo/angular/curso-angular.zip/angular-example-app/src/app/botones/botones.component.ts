import { Component } from '@angular/core';

@Component({
  selector: 'app-botones',
  imports: [],
  templateUrl: './botones.component.html',
  styleUrl: './botones.component.css'
})
export class BotonesComponent {
  src: string = "https://images.pexels.com/photos/30906509/pexels-photo-30906509/free-photo-of-majestuosas-montanas-cubiertas-de-nieve-en-banff-canada.jpeg?auto=compress&cs=tinysrgb&w=300&lazy=load";
}
