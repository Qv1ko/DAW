import { Routes } from '@angular/router';
import { routesList } from './app-routing.module';

export const routes: Routes = routesList;
