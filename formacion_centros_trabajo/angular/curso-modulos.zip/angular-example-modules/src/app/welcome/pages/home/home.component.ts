import { Component } from '@angular/core';
import { NavigationComponent } from "../../../shared/components/navigation/navigation.component";
import { SharedModule } from "../../../shared/shared.module";
import { FooterComponent } from "../../../shared/components/footer/footer.component";

@Component({
  imports: [NavigationComponent, SharedModule, FooterComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

}
