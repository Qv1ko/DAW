import pc from "picocolors";

console.log(pc.bgGreen("Prueba de picocolors")); // node .\print.js
